#ifndef HEADER
#define HEADER

#include <iostream>

class Header{
public:
  void print();
};

#endif
