#include "hello_ros/header.h"

void Header::print()
{
  std::cout << "Header Test Success!" << std::endl;
}
